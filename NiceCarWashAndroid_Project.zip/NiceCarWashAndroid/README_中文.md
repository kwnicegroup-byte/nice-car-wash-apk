# Nice Car Wash Android 原生项目（首版）

这是 Android Studio 项目源码，不是已编译 APK。

## 已实现的首版功能
- 原生 Android 界面，手机桌面安装图标
- 普通洗车 RM15、大车 RM20、高级洗车 RM30
- 其他服务：打蜡、内部吸尘、清洗脚垫、其他临时服务（可输入名称）
- SQLite 本机订单保存
- 今日营业额、现金 / DuitNow QR、员工汇总
- 选择手机已配对的蓝牙打印机，并尝试通过 ESC/POS 串口打印收据

## 重要限制
- 必须使用 Android Studio 和 Android SDK 编译成 APK；当前生成环境没有 Android SDK / Gradle，因此此处无法诚实地提供已编译 APK。
- 蓝牙打印目前针对常见 ESC/POS SPP 模式；购买前必须确认打印机支持 Android 蓝牙串口（SPP）和 ESC/POS，并在目标手机上实测。
- 老板 PIN 是演示用默认值 1234，尚未实现安全的 PIN 修改/权限管理。
- 订单暂存于本机 SQLite，尚无云端同步、自动云备份或 CSV 导出。
- DuitNow QR 只记录付款方式，不会自动验证银行收款。
- 正式营业前建议补齐更改 PIN、作废订单审计、数据导出/备份、打印机设置和完整实机测试。

## 编译 APK
1. 在电脑安装 Android Studio（支持 Android SDK 35）。
2. 解压 ZIP，在 Android Studio 选择 Open，打开 `NiceCarWashAndroid` 文件夹。
3. 等待 Gradle Sync 完成。
4. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. 测试 APK 通常会出现在 `app/build/outputs/apk/debug/app-debug.apk`。
6. 将 APK 传到 Android 手机安装。手机可能需要允许该来源安装应用。

建议先在真实手机上测试开单、关掉重开后订单是否保留，以及实际打印机是否兼容。
