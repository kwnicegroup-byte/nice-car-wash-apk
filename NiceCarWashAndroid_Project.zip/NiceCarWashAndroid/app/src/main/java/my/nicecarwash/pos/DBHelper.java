package my.nicecarwash.pos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.*;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context c){super(c,"nice_car_wash.db",null,1);}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE orders (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, time TEXT, plate TEXT, vehicle TEXT, service TEXT, price REAL, payment TEXT, staff TEXT, status TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){}
    public long addOrder(String date,String time,String plate,String vehicle,String service,double price,String payment,String staff,String status){
        ContentValues v=new ContentValues();v.put("date",date);v.put("time",time);v.put("plate",plate);v.put("vehicle",vehicle);v.put("service",service);v.put("price",price);v.put("payment",payment);v.put("staff",staff);v.put("status",status);
        return getWritableDatabase().insert("orders",null,v);
    }
    public List<Order> ordersForDate(String date){
        List<Order> out=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,date,time,plate,vehicle,service,price,payment,staff,status FROM orders WHERE date=? ORDER BY id DESC",new String[]{date});
        try{while(c.moveToNext()){Order o=new Order();o.id=c.getLong(0);o.date=c.getString(1);o.time=c.getString(2);o.plate=c.getString(3);o.vehicle=c.getString(4);o.service=c.getString(5);o.price=c.getDouble(6);o.payment=c.getString(7);o.staff=c.getString(8);o.status=c.getString(9);out.add(o);}}finally{c.close();}return out;
    }
    public static class Order {long id;String date,time,plate,vehicle,service,payment,staff,status;double price;}
}
