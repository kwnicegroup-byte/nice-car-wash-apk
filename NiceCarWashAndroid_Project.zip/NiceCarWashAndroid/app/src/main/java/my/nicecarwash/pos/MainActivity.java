package my.nicecarwash.pos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DBHelper db;
    LinearLayout root, body;
    String selectedService = "";
    double selectedPrice = 0;
    final String[] mainServices = {"普通洗车 / Normal Wash", "普通洗车（大车） / Large Vehicle", "高级洗车 / Premium Wash", "其他服务 / Other Services"};
    final double[] mainPrices = {15,20,30,0};
    final String[] otherServices = {"打蜡 Waxing", "内部吸尘 Interior Vacuum", "清洗脚垫 Floor Mat Cleaning", "其他临时服务 Other"};
    EditText plateInput, priceInput, customInput;
    Spinner vehicleSpinner, staffSpinner, paymentSpinner;
    BluetoothAdapter bluetoothAdapter;
    static final int REQ_BT = 101;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DBHelper(this);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        showHome();
    }

    TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xff172033); t.setPadding(4,8,4,8); return t;
    }
    Button button(String label, Runnable r) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(v -> r.run()); return b;
    }
    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16,12,16,16); root.setBackgroundColor(0xfff3f6f9);
        TextView head = text("NICE CAR WASH\n" + title, 22);
        head.setTextColor(0xffffffff); head.setBackgroundColor(0xff111827);
        head.setPadding(16,18,16,18); root.addView(head);
        ScrollView sc = new ScrollView(this);
        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(0,10,0,10);
        sc.addView(body); root.addView(sc, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void showHome() {
        base("员工开单 · Staff POS");
        body.addView(text("选择洗车服务",18));
        for(int i=0;i<mainServices.length;i++){
            final int ix=i;
            body.addView(button(mainServices[i] + (i<3 ? "    RM "+String.format(Locale.US,"%.2f",mainPrices[i]) : ""), () -> {
                if(ix<3){selectedService=mainServices[ix]; selectedPrice=mainPrices[ix]; showOrderForm();}
                else showOtherServices();
            }));
        }
        body.addView(button("老板每日营业额 / Owner Report", this::showOwnerReport));
        body.addView(button("连接蓝牙打印机 / Bluetooth Printer", this::choosePrinter));
        body.addView(text("订单保存在本机。请定期备份；本版本尚未实现云端同步。",12));
    }
    void showOtherServices() {
        base("其他服务 / Other Services");
        body.addView(text("请选择项目，再输入收费金额。",16));
        for(String s:otherServices) body.addView(button(s, () -> {
            if(s.startsWith("其他临时服务")) askCustomService();
            else { selectedService=s; askPrice(); }
        }));
        body.addView(button("返回 / Back", this::showHome));
    }
    void askCustomService() {
        EditText name = new EditText(this); name.setHint("临时服务名称 / Service name");
        EditText price = new EditText(this); price.setHint("收费金额 RM"); price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(24,8,24,8); l.addView(name); l.addView(price);
        new AlertDialog.Builder(this).setTitle("其他临时服务").setView(l)
            .setPositiveButton("继续", (d,w)->{
                String n=name.getText().toString().trim();
                if(n.isEmpty() || price.getText().toString().trim().isEmpty()){toast("请填写服务名称和价格");return;}
                selectedService=n; try{selectedPrice=Double.parseDouble(price.getText().toString());}catch(Exception e){toast("价格无效");return;}
                if(selectedPrice<0){toast("价格不能小于零");return;} showOrderForm();
            }).setNegativeButton("取消",null).show();
    }
    void askPrice() {
        EditText p=new EditText(this); p.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); p.setHint("收费金额 RM");
        new AlertDialog.Builder(this).setTitle(selectedService).setMessage("请输入本次收费金额").setView(p)
            .setPositiveButton("继续",(d,w)->{try{selectedPrice=Double.parseDouble(p.getText().toString()); if(selectedPrice<0)throw new Exception(); showOrderForm();}catch(Exception e){toast("请输入有效金额");}}).setNegativeButton("取消",null).show();
    }
    Spinner spinner(String[] vals) {
        Spinner s=new Spinner(this); s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, vals)); return s;
    }
    void showOrderForm() {
        base("新订单 / New Order");
        body.addView(text("服务："+selectedService+"    金额：RM "+String.format(Locale.US,"%.2f",selectedPrice),17));
        plateInput=new EditText(this); plateInput.setHint("车牌号码（可留空） / Plate No."); plateInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS); body.addView(plateInput);
        body.addView(text("车辆类型 / Vehicle",14)); vehicleSpinner=spinner(new String[]{"轿车 Sedan","SUV / MPV","Pickup / 大型车辆"});body.addView(vehicleSpinner);
        body.addView(text("员工 / Staff",14)); staffSpinner=spinner(new String[]{"员工 1 / Staff 1","员工 2 / Staff 2","员工 3 / Staff 3"});body.addView(staffSpinner);
        body.addView(text("付款方式 / Payment",14)); paymentSpinner=spinner(new String[]{"现金 Cash","DuitNow QR"});body.addView(paymentSpinner);
        body.addView(button("确认收款并保存订单 / Confirm Payment", () -> saveOrder()));
        body.addView(button("返回 / Back", this::showHome));
    }
    void saveOrder() {
        String plate=plateInput.getText().toString().trim().toUpperCase(Locale.ROOT); if(plate.isEmpty())plate="-";
        String date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        String time=new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date());
        String staff=staffSpinner.getSelectedItem().toString(), payment=paymentSpinner.getSelectedItem().toString();
        long id=db.addOrder(date,time,plate,vehicleSpinner.getSelectedItem().toString(),selectedService,selectedPrice,payment,staff,"PAID");
        String receipt=receipt(id,date,time,plate,selectedService,selectedPrice,payment,staff);
        new AlertDialog.Builder(this).setTitle("订单已保存")
            .setMessage("单号："+id+"\n金额：RM "+String.format(Locale.US,"%.2f",selectedPrice)+"\n是否打印收据？")
            .setPositiveButton("打印",(d,w)->printReceipt(receipt)).setNegativeButton("稍后",null)
            .setNeutralButton("完成",(d,w)->showHome()).show();
    }
    String receipt(long id,String date,String time,String plate,String service,double price,String payment,String staff) {
        return "       NICE CAR WASH\n          OFFICIAL RECEIPT\n--------------------------------\nReceipt No: "+id+"\nDate: "+date+" "+time+"\nPlate No: "+plate+"\n--------------------------------\n"+service+"\nAmount: RM "+String.format(Locale.US,"%.2f",price)+"\n--------------------------------\nTOTAL: RM "+String.format(Locale.US,"%.2f",price)+"\nPayment: "+payment+"\nStaff: "+staff+"\n\n     TERIMA KASIH!\n";
    }
    void printReceipt(String content) {
        if(bluetoothAdapter==null){toast("此手机没有蓝牙功能");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT); toast("请允许蓝牙权限后重新选择打印机"); return;
        }
        try {
            Set<BluetoothDevice> paired=bluetoothAdapter.getBondedDevices();
            if(paired.isEmpty()){toast("请先到手机设置配对蓝牙打印机");return;}
            ArrayList<BluetoothDevice> list=new ArrayList<>(paired); String[] names=new String[list.size()];
            for(int i=0;i<list.size();i++) names[i]=list.get(i).getName()+" ("+list.get(i).getAddress()+")";
            new AlertDialog.Builder(this).setTitle("选择已配对的打印机").setItems(names,(dlg,which)->new Thread(()->{
                try {
                    BluetoothDevice dev=list.get(which);
                    java.util.UUID uuid=java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
                    BluetoothSocket socket=dev.createRfcommSocketToServiceRecord(uuid);
                    socket.connect(); OutputStream out=socket.getOutputStream();
                    out.write(new byte[]{0x1b,0x40}); out.write(content.getBytes("GBK")); out.write(new byte[]{0x0a,0x0a,0x0a,0x1d,0x56,0x00}); out.flush(); out.close(); socket.close();
                    runOnUiThread(()->toast("已发送打印任务"));
                } catch(Exception e){runOnUiThread(()->toast("打印失败：请确认打印机兼容 ESC/POS 蓝牙串口模式")); }
            }).start()).show();
        } catch(SecurityException e){toast("缺少蓝牙权限，请在设置中允许");}
    }
    void choosePrinter() {
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT); return;
        }
        if(bluetoothAdapter==null){toast("此手机不支持蓝牙");return;}
        if(!bluetoothAdapter.isEnabled()){toast("请先在手机设置打开蓝牙");return;}
        toast("请在手机蓝牙设置中配对打印机，然后开单时选择打印。");
    }
    void showOwnerReport() {
        base("老板报表 / Owner Report");
        EditText pin=new EditText(this);pin.setHint("老板 PIN（默认 1234）");pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);body.addView(pin);
        body.addView(button("查看今日营业额",()->{
            if(!"1234".equals(pin.getText().toString())){toast("PIN 不正确（此原型默认 1234）");return;}
            String date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
            List<DBHelper.Order> orders=db.ordersForDate(date); double total=0,cash=0,qr=0;int count=0;
            StringBuilder report=new StringBuilder("日期："+date+"\n\n");
            Map<String,Double> staffTotals=new LinkedHashMap<>();
            for(DBHelper.Order o:orders){if(!"PAID".equals(o.status))continue;total+=o.price;count++;if(o.payment.startsWith("现金"))cash+=o.price;else qr+=o.price;staffTotals.put(o.staff,staffTotals.getOrDefault(o.staff,0.0)+o.price);}
            report.append("营业额：RM ").append(String.format(Locale.US,"%.2f",total)).append("\n洗车单数：").append(count)
                .append("\n现金：RM ").append(String.format(Locale.US,"%.2f",cash)).append("\nDuitNow QR：RM ").append(String.format(Locale.US,"%.2f",qr)).append("\n\n员工营业额：\n");
            for(String s:staffTotals.keySet())report.append(s).append("：RM ").append(String.format(Locale.US,"%.2f",staffTotals.get(s))).append("\n");
            for(DBHelper.Order o:orders) report.append("\n#").append(o.id).append(" ").append(o.time).append("\n").append(o.service).append(" / RM ").append(String.format(Locale.US,"%.2f",o.price)).append(" / ").append(o.staff).append(" / ").append(o.status);
            new AlertDialog.Builder(this).setTitle("每日营业额").setMessage(report.toString()).setPositiveButton("打印报表",(d,w)->printReceipt(report.toString())).setNegativeButton("关闭",null).show();
        }));
        body.addView(button("返回 / Back",this::showHome));
        body.addView(text("注意：当前原生项目为首版源码，正式营业前应加强 PIN 安全并实机测试打印机兼容性。",12));
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
